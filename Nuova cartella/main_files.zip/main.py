import sys
import os
import time
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import streamlit as st
from supabase import create_client
import json
from sqlalchemy import text
import plotly.subplots as sp
import plotly.graph_objects as go
from openpyxl import load_workbook
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import requests
from materialconvert_functions_5 import convert_curve, average_curves



############  PASSWORD #################

if "password_entered" not in st.session_state:
    st.session_state["password_entered"] = False

def check_password():
    def password_entered():
        if st.session_state["password_input"] == st.secrets["APP_PASSWORD"]:
            st.session_state["password_correct"] = True
            del st.session_state["password_input"]
        else:
            st.session_state["password_correct"] = False

    if "password_correct" not in st.session_state:
        st.image("imeva_logo.jpg", width=200)
        st.text_input("Enter password to access IMEVA Material Hub:", type="password", on_change=password_entered, key="password_input")
        return False
    elif not st.session_state["password_correct"]:
        st.image("imeva_logo.jpg", width=200)
        st.text_input("Enter password to access IMEVA Material Hub:", type="password", on_change=password_entered, key="password_input")
        st.error("Incorrect password")
        return False
    else:
        return True

if not check_password():
    st.stop()

# ------------------------------------------- START OF CODE ---------------------------------------------------------------------------------
##################################################################
############### SEND EMAIL PARTTTTT #############################
# --- Startup Diagnostic Test Email (Runs once upon login) ---
# --- Startup Diagnostic Test Email (Runs once upon login) ---

############### SEND EMAIL PARTTTTT #############################

# =========================================================================
# ### SECTION 1: PAGE CONFIGURATION & DATABASE SETUP ###
# =========================================================================
st.set_page_config(page_title="IMEVA Materials Hub", layout="wide")

@st.cache_resource
def init_supabase_client():
    url = st.secrets["connections"]["supabase"]["SUPABASE_URL"]
    key = st.secrets["connections"]["supabase"]["SUPABASE_KEY"]
    return create_client(url, key)

supabase_client = init_supabase_client()

st.cache_data.clear()
try:
    conn = st.connection("supabase", type="sql")
except Exception as e:
    st.error(f"IMEVA MATERIAL HUB ERROR: Failed to connect to Supabase Cloud Database: {e}")
    st.stop()

def upload_certificate_to_cloud(uploaded_file, lotto_identifier):
    """Uploads a certificate file to the Supabase 'certificate_storage' bucket and returns its public URL."""
    try:
        file_ext = uploaded_file.name.split('.')[-1]
        file_path = f"certs/{lotto_identifier}_{int(time.time())}.{file_ext}"
        
        # Push bytes to Supabase Storage
        supabase_client.storage.from_("certificate_storage").upload(
            path=file_path,
            file=uploaded_file.getvalue(),
            file_options={"content-type": uploaded_file.type, "upsert": "true"}
        )
        
        # Retrieve public URL
        public_url = supabase_client.storage.from_("certificate_storage").get_public_url(file_path)
        return public_url
    except Exception as e:
        st.error(f"Cloud Storage Upload Error: {e}")
        return None
    


@st.dialog("Supplier Mill Certificate Viewer", width="large")
def show_cert_modal(mat_name, cert_url, info):
    st.markdown(f"### Material: `{mat_name}`")
    st.write(f"**Grade:** {info.get('grade')} | **Lotto:** {info.get('lotto_number')} | **Provider:** {info.get('provider')}")
    st.divider()
    
    if cert_url:
        st.markdown(f"🔗 [Open certificate in a new browser tab]({cert_url})", unsafe_allow_html=True)
        if cert_url.lower().endswith(('.png', '.jpg', '.jpeg', '.webp')):
            st.image(cert_url, caption="Certificate Document", use_container_width=True)
        else:
            st.info("ℹ️ Inline PDF previews are often restricted by security policies. Use the link above if the viewer below appears empty.")
            st.markdown(f'<iframe src="{cert_url}" width="100%" height="600px"></iframe>', unsafe_allow_html=True)
    else:
        st.warning("No certificate URL provided.")



# Auto-restore spectrometer reports from Supabase into session state on app load
if "chemical_reports" not in st.session_state:
    st.session_state.chemical_reports = {}

if "reports_loaded_from_cloud" not in st.session_state:
    try:
        df_cloud_reports = conn.query("SELECT id, spectrometer_data_json FROM materials WHERE spectrometer_data_json IS NOT NULL;", ttl=0)
        
        for _, row in df_cloud_reports.iterrows():
            m_id = row.get("id")
            spec_json = row.get("spectrometer_data_json")
            
            if isinstance(spec_json, str):
                import json
                try:
                    spec_json = json.loads(spec_json)
                except Exception:
                    spec_json = {}
                    
            if spec_json and isinstance(spec_json, dict):
                df_records = spec_json.get("df_records", [])
                comp = spec_json.get("comp", {})
                if df_records:
                    reconstructed_df = pd.DataFrame(df_records)
                    st.session_state.chemical_reports[int(m_id)] = {
                        "df": reconstructed_df,
                        "comp": comp
                    }
        st.session_state.reports_loaded_from_cloud = True
    except Exception as e:
        pass


def fetch_cloud_materials(hub_section=None, family='METALS'):
    """Fetch entries filtered by hub section or return all for Production, aliasing certificate_url as datasheet."""
    if hub_section == "RD":
        query = """
            SELECT 
                id, parent_id, family, hub_section, grade, thickness, 
                yield_mpa, uts_mpa, elongation_pct, coil_weight_kg, coil_length_mm, 
                rd_remaining_weight_kg, rd_remaining_length_mm, rd_notes, 
                lotto_number, lotto_figlio, provider, 
                certificate_url AS datasheet, 
                is_promoted 
            FROM materials 
            WHERE (hub_section = 'RD' OR is_promoted = 1) AND family = :fam 
            ORDER BY id DESC;
        """
        return conn.query(query, params={"fam": family}, ttl=0)
    else:
        query = """
            SELECT 
                id, parent_id, family, hub_section, grade, thickness, 
                yield_mpa, uts_mpa, elongation_pct, coil_weight_kg, coil_length_mm, 
                rd_remaining_weight_kg, rd_remaining_length_mm, rd_notes, 
                lotto_number, lotto_figlio, provider, 
                certificate_url AS datasheet, 
                is_promoted 
            FROM materials 
            WHERE family = :fam 
            ORDER BY id DESC;
        """
        return conn.query(query, params={"fam": family}, ttl=0)

def insert_cloud_material(
    grade, thickness, yield_mpa, uts_mpa, elongation, lotto_padre, lotto_figlio, provider, 
    family, cert_path=None, coil_weight=0.0, coil_length=0.0, coil_length_mm=None
):
    """Insert new production batch into Supabase supporting mutually exclusive Padre/Figlio lottos."""
    actual_length = coil_length_mm if coil_length_mm is not None else coil_length
    
    with conn.session as s:
        s.execute(
            text("""
                INSERT INTO materials (
                    grade, thickness, yield_mpa, uts_mpa, elongation_pct, 
                    lotto_number, lotto_figlio, provider, family, certificate_url, 
                    coil_weight_kg, coil_length_mm,
                    rd_remaining_weight_kg, rd_remaining_length_mm
                )
                VALUES (
                    :grade, :thick, :ys, :uts, :elong, 
                    :l_padre, :l_figlio, :prov, :fam, :cert, 
                    :c_wt, :c_len, :c_wt, :c_len
                )
            """),
            {
                "grade": grade, "thick": thickness, "ys": yield_mpa, 
                "uts": uts_mpa, "elong": elongation, 
                "l_padre": lotto_padre if lotto_padre else None, 
                "l_figlio": lotto_figlio if lotto_figlio else None, 
                "prov": provider, "fam": family, "cert": cert_path, 
                "c_wt": coil_weight, "c_len": actual_length
            }
        )
        s.commit()

def split_cloud_material(parent_id, children_list):
    """Splits a parent coil into a dynamic number of child coils and zeros out the parent stock."""
    with conn.session as s:
        parent_res = s.execute(
            text("SELECT * FROM materials WHERE id = :id"), 
            {"id": int(parent_id)}
        ).mappings().first()
        
        if not parent_res:
            raise Exception("Parent material not found.")

        parent_lotto = parent_res['lotto_number'] if parent_res['lotto_number'] else parent_res['lotto_figlio']

        # Insert each child dynamically
        for child in children_list:
            s.execute(
                text("""
                    INSERT INTO materials (
                        parent_id, family, hub_section, grade, thickness, 
                        yield_mpa, uts_mpa, elongation_pct, coil_weight_kg, 
                        coil_length_mm, rd_remaining_weight_kg, rd_remaining_length_mm, 
                        lotto_number, lotto_figlio, provider, certificate_url, is_promoted
                    ) VALUES (
                        :parent_id, :family, :hub_section, :grade, :thickness, 
                        :yield_mpa, :uts_mpa, :elongation_pct, :coil_weight_kg, 
                        :coil_length_mm, :rd_remaining_weight_kg, :rd_remaining_length_mm, 
                        :lotto_number, :lotto_figlio, :provider, :certificate_url, 0
                    )
                """),
                {
                    "parent_id": parent_id,
                    "family": parent_res.get("family", "METALS"),
                    "hub_section": parent_res.get("hub_section", "PROD"),
                    "grade": parent_res["grade"],
                    "thickness": parent_res["thickness"],
                    "yield_mpa": parent_res["yield_mpa"],
                    "uts_mpa": parent_res["uts_mpa"],
                    "elongation_pct": parent_res["elongation_pct"],
                    "coil_weight_kg": child["weight"],
                    "coil_length_mm": child["length"],
                    "rd_remaining_weight_kg": child["weight"],
                    "rd_remaining_length_mm": child["length"],
                    "lotto_number": parent_lotto,
                    "lotto_figlio": child["lotto"],
                    "provider": parent_res["provider"],
                    "certificate_url": parent_res.get("certificate_url")
                }
            )

        # Zero out and deactivate Parent
        s.execute(
            text("""
                UPDATE materials 
                SET rd_remaining_weight_kg = 0.0, 
                    rd_remaining_length_mm = 0.0 
                WHERE id = :id
            """),
            {"id": int(parent_id)}
        )
        s.commit()

def log_material_consumption(material_id, weight_used_kg, length_used_mm, notes=""):
    """Deducts used weight/length from the selected material batch safely and clears cache."""
    with conn.session as s:
        s.execute(
            text("""
                UPDATE materials 
                SET rd_remaining_weight_kg = GREATEST(0.0, COALESCE(rd_remaining_weight_kg, coil_weight_kg) - :w_used),
                    rd_remaining_length_mm = GREATEST(0.0, COALESCE(rd_remaining_length_mm, coil_length_mm) - :l_used),
                    rd_notes = CASE 
                        WHEN rd_notes IS NULL OR rd_notes = '' THEN :notes
                        ELSE rd_notes || ' | ' || :notes
                    END
                WHERE id = :mat_id
            """),
            {"w_used": weight_used_kg, "l_used": length_used_mm, "notes": notes, "mat_id": int(material_id)}
        )
        s.commit()
    st.cache_data.clear()

def promote_cloud_material(material_id):
    """Marks batch as promoted while keeping it visible in Production Hub."""
    with conn.session as s:
        s.execute(text('UPDATE materials SET is_promoted = 1 WHERE id = :id'), {"id": int(material_id)})
        s.commit()

def delete_cloud_material(material_id):
    """Deletes a material batch, safely handling child foreign key constraints by unlinking."""
    with conn.session as s:
        # Unlink any child records pointing to this parent before deleting
        s.execute(
            text('UPDATE materials SET parent_id = NULL WHERE parent_id = :id'), 
            {"id": int(material_id)}
        )
        # Now safely delete the target record
        s.execute(
            text('DELETE FROM materials WHERE id = :id'), 
            {"id": int(material_id)}
        )
        s.commit()

def demote_cloud_material(material_id):
    """Un-promote batch so it returns to production and leaves R&D deck."""
    with conn.session as s:
        s.execute(text('''
            UPDATE materials
            SET is_promoted = 0,
                experimental_curves_json = NULL,
                calculated_sigy_mpa = NULL,
                calculated_uts_mpa = NULL,
                calculated_e_gpa = NULL,
                calculated_elongation_pct = NULL
            WHERE id = :id
        '''), {"id": int(material_id)})
        s.commit()
    if material_id in st.session_state.get("experimental_curves", {}):
        del st.session_state.experimental_curves[material_id]
    st.cache_data.clear()

def update_cloud_material(
    mat_id, 
    grade, 
    thickness, 
    yield_mpa, 
    uts_mpa, 
    elongation_pct, 
    lotto_number, 
    lotto_figlio, 
    provider, 
    coil_weight_kg, 
    coil_length_mm
):
    with conn.session as s:
        s.execute(
            text("""
                UPDATE materials SET 
                    grade = :grade,
                    thickness = :thickness,
                    yield_mpa = :yield_mpa,
                    uts_mpa = :uts_mpa,
                    elongation_pct = :elongation_pct,
                    lotto_number = :lotto_number,
                    lotto_figlio = :lotto_figlio,
                    provider = :provider,
                    coil_weight_kg = :coil_weight_kg,
                    coil_length_mm = :coil_length_mm
                WHERE id = :id
            """),
            params={
                "id": int(mat_id),
                "grade": grade,
                "thickness": float(thickness),
                "yield_mpa": float(yield_mpa),
                "uts_mpa": float(uts_mpa),
                "elongation_pct": float(elongation_pct),
                "lotto_number": lotto_number,
                "lotto_figlio": lotto_figlio, 
                "provider": provider,
                "coil_weight_kg": float(coil_weight_kg),
                "coil_length_mm": float(coil_length_mm)
            }
        )
        s.commit()

# =========================================================================
# ### SECTION 2: REGULATORY COMPLIANCE HELPER FUNCTIONS ###
# =========================================================================
def get_en10025_limits(grade, thickness):
    """Evaluates standard EN 10025 structural limits based on grade and thickness."""
    clean_grade = str(grade).upper().replace("JR", "").strip()
    if "S355" in clean_grade:
        y = 355 if thickness <= 16.0 else 345
        uts_min, uts_max = 470, 630
    elif "S275" in clean_grade:
        y = 275 if thickness <= 16.0 else 265
        uts_min, uts_max = 410, 560
    elif "S500" in clean_grade:
        y = 500 if thickness <= 16.0 else 490
        uts_min, uts_max = 590, 720
    else:
        y = 235 if thickness <= 16.0 else 225
        uts_min, uts_max = 360, 510
    return {"min_yield": y, "min_uts": uts_min, "max_uts": uts_max}

#### upload chemical composition.. from LAB  

def parse_metal_power_excel(uploaded_file):
    """Parses Metal Power Spectrometer Excel reports, drops Date/Time, and cleans symbol values."""
    try:
        df_raw = pd.read_excel(uploaded_file, header=None, engine="calamine")
        
        header_row_idx = None
        for idx, row in df_raw.iterrows():
            row_str_vals = [str(val).strip() for val in row.values if val is not None]
            if "Elements" in row_str_vals or any("C (%)" in val for val in row_str_vals):
                header_row_idx = idx
                break
        
        if header_row_idx is not None:
            df_raw.columns = [str(col).strip() for col in df_raw.iloc[header_row_idx].values]
            df = df_raw.iloc[header_row_idx + 1:].reset_index(drop=True)
        else:
            df = df_raw
            df.columns = [str(col).strip() for col in df.iloc[0].values]
            df = df.iloc[1:].reset_index(drop=True)
            
        df.columns = [str(col).strip() for col in df.columns]
        
        # Drop Date/Time column if it exists
        if "Date/Time" in df.columns:
            df = df.drop(columns=["Date/Time"])
            
        mean_row = df[df.iloc[:, 0].astype(str).str.contains("Mean", case=False, na=False)]
        if not mean_row.empty:
            target_data = mean_row.iloc[0]
        else:
            target_data = df.iloc[-1]
            
        composition = {}
        for col in df.columns:
            if "(%)" in col:
                val_str = str(target_data[col]).strip()
                # Remove '<', '>', '-', and extra whitespace
                clean_val = val_str.replace("<", "").replace(">", "").replace("-", "").strip()
                try:
                    composition[col] = float(clean_val)
                except ValueError:
                    composition[col] = 0.0  
                    
        return df, composition
    except Exception as e:
        st.error(f"Error parsing spectrometer report: {e}")
        return None, None
###########################  END OF CHEMICAL COMPOSITION ##################

# =========================================================================
# ### SECTION 3: APPLICATION NAVIGATION INITIALIZATION ###
# =========================================================================
if "current_page" not in st.session_state:
    st.session_state.current_page = "HOME"
if "selected_material" not in st.session_state:
    st.session_state.selected_material = None
if "active_family" not in st.session_state:
    st.session_state.active_family = "METALS"
if "experimental_curves" not in st.session_state:
    st.session_state.experimental_curves = {}
if "chemical_reports" not in st.session_state:
    st.session_state.chemical_reports = {}
################################################################################
if "curves_loaded_from_cloud" not in st.session_state:
    try:
        df_cloud_curves = conn.query("SELECT id, experimental_curves_json FROM materials WHERE experimental_curves_json IS NOT NULL;", ttl=0)
        
        for _, row in df_cloud_curves.iterrows():
            m_id = row.get("id")
            mech_json = row.get("experimental_curves_json")
            
            if isinstance(mech_json, str):
                import json
                try:
                    mech_json = json.loads(mech_json)
                except Exception:
                    mech_json = {}
                    
            if mech_json and isinstance(mech_json, dict):
                st.session_state.experimental_curves[int(m_id)] = {
                    "strain": np.array(mech_json.get("strain", [])),
                    "stress_MPa": np.array(mech_json.get("stress_MPa", [])),
                    "sigy_MPa": mech_json.get("sigy_MPa"),
                    "uts_MPa": mech_json.get("uts_MPa"),
                    "E_GPa": mech_json.get("E_GPa"),
                    "elongation_pct": mech_json.get("elongation_pct"),
                    "avg_strain": np.array(mech_json.get("avg_strain", [])),
                    "avg_stress": np.array(mech_json.get("avg_stress", [])),
                    "eng_strain_clean": np.array(mech_json.get("eng_strain_clean", [])),
                    "eng_stress_clean": np.array(mech_json.get("eng_stress_clean", [])),
                    "deck": mech_json.get("deck")
                }
        st.session_state.curves_loaded_from_cloud = True
    except Exception as e:
        pass

# =========================================================================
# ### SECTION 4: HOME PAGE (CENTRAL PORTAL LANDING) ###
# =========================================================================
if st.session_state.current_page == "HOME":
    logo_left, logo_mid, logo_right = st.columns([3, 1, 3])
    with logo_mid:
        if os.path.exists("imeva_logo.jpg"):
            st.image("imeva_logo.jpg", width=200)
        elif os.path.exists("imeva.jpg"):
            st.image("imeva.jpg", width=200)
            
    st.markdown("<h1 style='text-align: center; color: #28A745;'>IMEVA Materials Hub</h1>", unsafe_allow_html=True)
    st.markdown("<p style='text-align: center; font-weight: 600;'>Select a material family and choose either the R&D Deck or Production Hub.</p>", unsafe_allow_html=True)
    st.markdown("<p style='text-align: center; color: #666; font-style: italic; margin-top: -10px;'>Azienda leader nella produzione di barriere stradali — Benvenuti</p>", unsafe_allow_html=True)
    st.write("---")

    # --- BANNER IMAGE (Centered and Compact) ---
    if os.path.exists("road_2.png"):
        img_left_pad, img_center, img_right_pad = st.columns([1.5, 2, 1.5])
        with img_center:
            st.image("road_2.png", use_container_width=True, caption="IMEVA Road Safety Barrier Installation")

    st.write("---")

    col1, col2, col3 = st.columns(3)
    with col1:
        st.markdown("### Metals Family")
        st.caption("Structural Steel, EN 10025 compliance, tensile strain curves, and batch tracking.")
        box_rd, box_prod = st.columns(2)
        with box_rd:
            st.info("R&D Deck")
            if st.button("Open R&D", key="metals_rd_btn", use_container_width=True):
                st.session_state.active_family = "METALS"
                st.session_state.current_page = "RD_DECK"
                st.rerun()
        with box_prod:
            st.success("Production Hub")
            if st.button("Open Prod", key="metals_prod_btn", use_container_width=True):
                st.session_state.active_family = "METALS"
                st.session_state.current_page = "PROD_HUB"
                st.rerun()

    with col2:
        st.markdown("### Polymers Family")
        st.caption("Viscoelastic/viscoplastic material models & extrusion quality tracking.")
        box_rd, box_prod = st.columns(2)
        with box_rd:
            st.info("R&D Deck")
            st.button("Locked", key="poly_rd_btn", disabled=True, use_container_width=True)
        with box_prod:
            st.success("Production Hub")
            st.button("Locked", key="poly_prod_btn", disabled=True, use_container_width=True)

    with col3:
        st.markdown("### Composites Family")
        st.caption("Orthotropic failure criteria, layups, & coupon production tracking.")
        box_rd, box_prod = st.columns(2)
        with box_rd:
            st.info("R&D Deck")
            st.button("Locked", key="comp_rd_btn", disabled=True, use_container_width=True)
        with box_prod:
            st.success("Production Hub")
            st.button("Locked", key="comp_prod_btn", disabled=True, use_container_width=True)
# =========================================================================
# ### SECTION 5: R&D LABORATORY DECK PAGE ###
# =========================================================================
elif st.session_state.current_page == "RD_DECK":
    if st.button("← Return to Central Portal"):
        st.session_state.current_page = "HOME"
        st.session_state.selected_material = None
        st.rerun()
        
    family_name = st.session_state.active_family.title()
    st.title(f"{family_name} R&D Laboratory Deck")
    st.write("---")
    
    sq_rd_df = fetch_cloud_materials("RD", family=st.session_state.active_family)
    
    combined_materials = {}
    for _, row in sq_rd_df.iterrows():
        mat_id = int(row['id'])
        
        # --- [BLOCK 2] AUTO-RESTORE MECHANICAL DATA FROM SUPABASE IF NOT IN SESSION ---
        if mat_id not in st.session_state.experimental_curves and pd.notna(row.get('experimental_curves_json')):
            try:
                raw_mech = row['experimental_curves_json']
                mech_data = json.loads(raw_mech) if isinstance(raw_mech, str) else raw_mech
                st.session_state.experimental_curves[mat_id] = {
                    "strain": np.array(mech_data.get("strain", [])),
                    "stress_MPa": np.array(mech_data.get("stress_MPa", [])),
                    "sigy_MPa": mech_data.get("sigy_MPa", 0.0),
                    "uts_MPa": mech_data.get("uts_MPa", 0.0),
                    "E_GPa": mech_data.get("E_GPa", 0.0),
                    "elongation_pct": mech_data.get("elongation_pct", 0.0),
                    "avg_strain": np.array(mech_data.get("avg_strain", [])),
                    "avg_stress": np.array(mech_data.get("avg_stress", [])),
                    "eng_strain_clean": np.array(mech_data.get("eng_strain_clean", [])),
                    "eng_stress_clean": np.array(mech_data.get("eng_stress_clean", [])),
                    "deck": mech_data.get("deck", "")
                }
            except Exception:
                pass
        # --------------------------------------------------------------------

        grade_str = str(row['grade'])
        thick_val = float(row['thickness'])
        lotto_str = str(row['lotto_number']) if pd.notna(row['lotto_number']) else "N/A"
        cert_sy = float(row['yield_mpa'])
        cert_sf = float(row['uts_mpa'])
        
        # --- EXTRACT COIL METRICS & R&D TRACKING FIELDS ---
        c_weight = float(row.get('coil_weight_kg') or 0.0)
        c_length = float(row.get('coil_length_mm') or 0.0)
        rd_rem_weight = float(row.get('rd_remaining_weight_kg') if pd.notna(row.get('rd_remaining_weight_kg')) else c_weight)
        rd_rem_length = float(row.get('rd_remaining_length_mm') if pd.notna(row.get('rd_remaining_length_mm')) else c_length)
        rd_notes_val = str(row.get('rd_notes') or "")
        
        #st.markdown(f"""
        #**Remaining Stock:** **{rd_rem_weight:.1f} kg** / **{rd_rem_length:.1f} mm**  
        #*(Original Baseline: {c_weight:.1f} kg / {c_length:.1f} mm)*  
       # 📝 **Notes / Log History:** {rd_notes_val if rd_notes_val else "No cuts logged yet."}
       # """)
        
        lab_data = st.session_state.experimental_curves.get(mat_id, {})
        lab_sy = f"{lab_data.get('sigy_MPa', 0.0):.0f}" if lab_data else "-"
        lab_sf = f"{lab_data.get('uts_MPa', 0.0):.0f}" if lab_data else "-"

        display_label = (
            f"{grade_str}-SP{thick_val:.1f}-{lotto_str} "
            f"[Cert: {cert_sy:.0f}, {cert_sf:.0f} | Lab: {lab_sy}, {lab_sf}]"
        )
        
        combined_materials[display_label] = {
            "id": mat_id,
            "grade": grade_str,
            "thickness": thick_val,
            "cert_yield_MPa": cert_sy,
            "cert_uts_MPa": cert_sf,
            "lotto": lotto_str,
            "coil_weight_kg": c_weight,
            "coil_length_mm": c_length,
            "rd_remaining_weight_kg": rd_rem_weight,
            "rd_remaining_length_mm": rd_rem_length,
            "rd_notes": rd_notes_val,
            "datasheet": row['datasheet'] if pd.notna(row['datasheet']) else None
        }

    # ==========================================
    # PROFESSIONAL STACKED FILTER HUB
    # ==========================================
    st.sidebar.markdown("Property Filters")
    
    available_grades = sorted(list(set(info["grade"] for info in combined_materials.values()))) if combined_materials else ["All"]
    filter_grade = st.sidebar.selectbox("Steel Class / Grade", ["All"] + available_grades)

    st.sidebar.write("---")

    st.sidebar.markdown("Thickness")
    enable_thick_filter = st.sidebar.checkbox("Filter by Exact Thickness", value=True)
    
    available_thicknesses = sorted(list(set(meta.get("thickness", 3.0) for meta in combined_materials.values()))) if combined_materials else [3.0]
    
    selected_thickness = st.sidebar.number_input(
        "Nominal Thickness [mm]", 
        min_value=1.0, 
        max_value=20.0, 
        value=float(available_thicknesses[0]) if available_thicknesses else 3.0, 
        step=0.1, 
        format="%.1f"
    ) if enable_thick_filter else None

    st.sidebar.write("---")

    with st.sidebar.expander(" Supplier Cert. or/& Laboratory", expanded=True):
        cert_status_filter = st.radio( 
            "Select Data mode",
            ["All Batches", "Supplier Cert.", "Laboratory"]
        )

    with st.sidebar.expander("Mech. prop", expanded=True):
        min_yield, max_yield = st.slider(
            "Yield Stress Range (σ_yield) [MPa]", 
            min_value=100.0, max_value=1000.0, value=(100.0, 1000.0), step=10.0
        )
        min_uts, max_uts = st.slider(
            "Tensile Stress Range (σ_uts) [MPa]", 
            min_value=100.0, max_value=1200.0, value=(100.0, 1200.0), step=10.0
        )
        min_elong, max_elong = st.slider(
            "Elongation Range [%]",
            min_value=0.0, max_value=50.0, value=(0.0, 50.0), step=0.5
        )

    # ==========================================
    # FILTERING EXECUTION LOGIC
    # ==========================================
    # 2. Main Layout Filter Logic
    filtered_materials = {}
    for name, metadata in combined_materials.items():
        grade_match = (filter_grade == "All" or metadata.get("grade") == filter_grade)
        thick_val = metadata.get("thickness", 0)
        thickness_match = True if not enable_thick_filter else (abs(thick_val - selected_thickness) <= 0.05)
        
        mat_id = metadata.get("id")
        
        if cert_status_filter == "Supplier Cert.":
            active_yield = metadata.get("cert_yield_MPa", 0)
            active_uts = metadata.get("cert_uts_MPa", 0)
            active_elong = metadata.get("elongation_pct", 0)
            cert_match = True
        elif cert_status_filter == "Laboratory":
            session_data = st.session_state.experimental_curves.get(mat_id, {})
            active_yield = session_data.get("sigy_MPa", metadata.get("sigy_MPa", 0))
            active_uts = session_data.get("uts_MPa", metadata.get("uts_MPa", 0))
            active_elong = session_data.get("elongation_pct", session_data.get("elongation", metadata.get("elongation_pct", 0)))
            
            has_metadata_lab = metadata.get("sigy_MPa") is not None
            has_session_lab = mat_id in st.session_state.experimental_curves
            cert_match = bool(has_metadata_lab or has_session_lab)
        else: 
            active_yield = metadata.get("sigy_MPa", metadata.get("cert_yield_MPa", 0))
            active_uts = metadata.get("uts_MPa", metadata.get("cert_uts_MPa", 0))
            active_elong = metadata.get("elongation_pct", 0)
            cert_match = True

        yield_match = min_yield <= active_yield <= max_yield
        uts_match = min_uts <= active_uts <= max_uts
        elong_match = min_elong <= active_elong <= max_elong

        if grade_match and thickness_match and yield_match and uts_match and elong_match and cert_match:
            filtered_materials[name] = metadata

    main_col, chart_col = st.columns([1, 1])

    # 3. Apply the loop with clean, deduplicated card columns
    with main_col:
        st.subheader("Available Inventory & Promoted Batches")
        st.caption("Format: `[Cert: YS, UTS | Lab: YS, UTS]`")
        if not combined_materials:
            st.info("No materials promoted to R&D yet. Add and promote batches from the Production Hub.")
        elif not filtered_materials:
            st.warning("No promoted materials match the current sidebar filter limits.")
        else:
            for mat_name, info in filtered_materials.items():
                limits = get_en10025_limits(info["grade"], info["thickness"])
                is_compliant = info["cert_yield_MPa"] >= limits["min_yield"]
                
                rem_len = info["rd_remaining_length_mm"]
                rem_weight = info["rd_remaining_weight_kg"]
                orig_weight = info["coil_weight_kg"]
                inv_badge = "🟢 Available" if rem_len > 10.0 else "🔴 Low Stock"
                status_badge = "✅ EN Compliant" if is_compliant else "❌ Non-Compliant"
                st.markdown(f"**Status:** {status_badge} | {inv_badge} | **Stock:** {rem_weight:.1f} kg / {rem_len:.1f} mm")
                
                card_col1, card_col2 = st.columns([3, 1])
                with card_col1:
                    title_col, prev_col = st.columns([4, 1])
                    with title_col:
                        st.markdown(f"#### `{mat_name}`")
                    with prev_col:
                        cert_url = info.get("datasheet")
                        if cert_url:
                            if st.button("🔍 View Cert", key=f"btn_cert_{info['id']}"):
                                show_cert_modal(mat_name, cert_url, info)
                        else:
                            st.markdown("*(No Cert)*")
                            
                with card_col2:
                    if st.button("↩️ Un-promote", key=f"demote_rd_{info['id']}", help="Send back to Production Hub"):
                        demote_cloud_material(info['id'])
                        st.toast("Material un-promoted and sent back to Production!")
                        st.rerun()

                if st.button(f"Analyze & Process Data", key=f"btn_{info['id']}", use_container_width=True):
                    st.session_state.selected_material = mat_name
                
                st.divider()

    # 4. Maintain the Charts Column 
    with chart_col:
        st.subheader("Inventory Properties Group Overview")
        if filtered_materials:
            batches = list(filtered_materials.keys())
            yields = [info["cert_yield_MPa"] for info in filtered_materials.values()]
            utss = [info["cert_uts_MPa"] for info in filtered_materials.values()]

            x = np.arange(len(batches))
            width = 0.35

            fig_bar, ax_bar = plt.subplots(figsize=(6, 3.8))
            rects1 = ax_bar.bar(x - width/2, yields, width, label='σ_yield (MPa)', color='#1E3A8A')
            rects2 = ax_bar.bar(x + width/2, utss, width, label='σ_uts / failure (MPa)', color='#D97706')

            ax_bar.set_ylabel('Stress [MPa]')
            ax_bar.set_title('Strength Properties Comparison')
            ax_bar.set_xticks(x)
            ax_bar.set_xticklabels(batches, rotation=15, ha='right', fontsize=8)
            ax_bar.legend()
            ax_bar.grid(axis='y', linestyle=':', alpha=0.7)
            
            ax_bar.bar_label(rects1, padding=3, fmt='%.0f')
            ax_bar.bar_label(rects2, padding=3, fmt='%.0f')

            fig_bar.tight_layout()
            st.pyplot(fig_bar)
            
            st.subheader("📈 Multi-Material Comparative Curves")
            fig_comp, ax_comp = plt.subplots(figsize=(6, 3.8))
            curves_plotted = 0

            for mat_name, info in filtered_materials.items():
                mat_id = info["id"]
                if mat_id in st.session_state.experimental_curves:
                    exp = st.session_state.experimental_curves[mat_id]
                    # Robust fallback for lotto identifier legend bug
                    lot_name = info.get('lotto') or info.get('lotto_number') or info.get('lotto_figlio') or 'N/A'
                    ax_comp.plot(exp["strain"], exp["stress_MPa"], label=f"Lot: {lot_name}", lw=2)
                    curves_plotted += 1

            if curves_plotted > 0:
                ax_comp.set_xlabel("Strain [-]")
                ax_comp.set_ylabel("Stress [MPa]")
                ax_comp.set_title("Experimental Stress-Strain Overlay")
                ax_comp.grid(True, linestyle=":")
                ax_comp.legend()
                fig_comp.tight_layout()
                st.pyplot(fig_comp)
            else:
                st.info("Click 'Analyze & Process Data' below to upload CSV dog bone tests for curve plotting.")
        else:
            st.caption("Awaiting inventory entries to generate strength comparison bars.")

    # ---------------------------------------------------------------------
    # ### SUB-SECTION: DETAILED REVIEW & EXPERIMENTAL MULTI-CSV ANALYSIS ###
    # ---------------------------------------------------------------------
    if st.session_state.selected_material and st.session_state.selected_material in combined_materials:
        mat_name = st.session_state.selected_material
        mat_info = combined_materials[mat_name]
        mat_id = mat_info["id"]
        
        st.write("---")
        st.header(f"📊 Detailed Review Deck: {mat_name}")
        
        props_col, action_col = st.columns([1, 1])
        
        with props_col:
            st.subheader("📜 Material Mill Certificate Parameters")
            st.write(f"**Structural Grade:** {mat_info['grade']}")
            st.write(f"**Nominal Thickness:** {mat_info['thickness']} mm")
            st.write(f"**Lotto :** {mat_info.get('lotto') or mat_info.get('lotto_number') or 'N/A'}")
            st.write(f"**Yield Stress ($R_e$):** {mat_info['cert_yield_MPa']} MPa")
            st.write(f"**Tensile Stress ($R_m$):** {mat_info['cert_uts_MPa']} MPa")

            st.markdown("---")
            st.subheader("Log Material Usage")
            
            init_w = float(mat_info.get("coil_weight_kg") or 0.0)
            init_l = float(mat_info.get("coil_length_mm") or 0.0)
            
            raw_rem_w = mat_info.get("rd_remaining_weight_kg")
            raw_rem_l = mat_info.get("rd_remaining_length_mm")
            
            curr_rem_w = float(raw_rem_w) if raw_rem_w is not None else init_w
            curr_rem_l = float(raw_rem_l) if raw_rem_l is not None else init_l

            if curr_rem_w <= 0.001:
                curr_rem_w = 0.0
            if curr_rem_l <= 0.01:
                curr_rem_l = 0.0

            rd_notes_val = mat_info.get("rd_notes") or mat_info.get("notes")

            st.markdown(f"""
            **Remaining Stock:** **{curr_rem_w:.1f} kg** / **{curr_rem_l:.2f} mm**  
            *(Original Baseline: {init_w:.1f} kg / {init_l:.1f} mm)*  
            📝**Notes / Log History:** {rd_notes_val if rd_notes_val else "No cuts logged yet."}
            """)

            with st.form(key=f"rd_tracker_form_{mat_id}"):
                col_w1, col_w2 = st.columns(2)
                with col_w1:
                    weight_consumed = st.number_input("Weight Used [kg]", value=0.0, step=0.1)
                with col_w2:
                    length_consumed = st.number_input("Length Used [mm]", value=0.0, step=100.0)
                
                usage_notes = st.text_input("Usage Purpose / Notes", value="")
                
                if st.form_submit_button("📉 Deduct & Update Inventory", use_container_width=True):
                    try:
                        log_material_consumption(
                            material_id=mat_id,
                            weight_used_kg=weight_consumed,
                            length_used_mm=length_consumed,
                            notes=usage_notes
                        )
                        st.success("Material usage logged and inventory deducted successfully!")
                        st.cache_data.clear()
                        st.rerun()
                    except Exception as e:
                        st.error(f"Failed to record consumption: {e}")

            st.markdown("---")
            st.subheader("🔬 Chemical Composition Analysis")
            uploaded_spec = st.file_uploader("Upload Spectrometer Report (Excel/CSV)", type=["xlsx", "csv"], key=f"spec_{mat_id}")
        
        if uploaded_spec is not None:
            df_spec, comp_dict = parse_metal_power_excel(uploaded_spec)
            if comp_dict is not None:
                st.session_state.chemical_reports[mat_id] = {"df": df_spec, "comp": comp_dict}
                
                temp_numeric = {
                    k.replace(" (%)", ""): v for k, v in comp_dict.items() 
                    if isinstance(v, (int, float)) and "Fe" not in k
                }
                
                try:
                    c_v = next((v for k, v in temp_numeric.items() if k.strip().upper() == "C"), 0.0)
                    mn_v = next((v for k, v in temp_numeric.items() if k.strip().upper() == "MN"), 0.0)
                    cr_v = next((v for k, v in temp_numeric.items() if k.strip().upper() == "CR"), 0.0)
                    mo_v = next((v for k, v in temp_numeric.items() if k.strip().upper() == "MO"), 0.0)
                    v_v = next((v for k, v in temp_numeric.items() if k.strip().upper() == "V"), 0.0)
                    ni_v = next((v for k, v in temp_numeric.items() if k.strip().upper() == "NI"), 0.0)
                    cu_v = next((v for k, v in temp_numeric.items() if k.strip().upper() == "CU"), 0.0)
                    calc_cev = float(c_v) + float(mn_v)/6.0 + (float(cr_v)+float(mo_v)+float(v_v))/5.0 + (float(ni_v)+float(cu_v))/15.0
                except Exception:
                    calc_cev = 0.0

                try:
                    df_json_records = df_spec.to_dict(orient="records") if df_spec is not None else []
                    spec_payload = json.dumps({"df_records": df_json_records, "comp": comp_dict})
                    
                    c_val_db = next((v for k, v in temp_numeric.items() if k.strip().upper() == "C"), 0.0)
                    si_val_db = next((v for k, v in temp_numeric.items() if k.strip().upper() == "SI"), 0.0)
                    mn_val_db = next((v for k, v in temp_numeric.items() if k.strip().upper() == "MN"), 0.0)
                    p_val_db = next((v for k, v in temp_numeric.items() if k.strip().upper() == "P"), 0.0)
                    s_val_db = next((v for k, v in temp_numeric.items() if k.strip().upper() == "S"), 0.0)
                    cr_val_db = next((v for k, v in temp_numeric.items() if k.strip().upper() == "CR"), 0.0)
                    mo_val_db = next((v for k, v in temp_numeric.items() if k.strip().upper() == "MO"), 0.0)
                    ni_val_db = next((v for k, v in temp_numeric.items() if k.strip().upper() == "NI"), 0.0)
                    cu_val_db = next((v for k, v in temp_numeric.items() if k.strip().upper() == "CU"), 0.0)
                    al_val_db = next((v for k, v in temp_numeric.items() if k.strip().upper() == "AL"), 0.0)
                    as_val_db = next((v for k, v in temp_numeric.items() if k.strip().upper() == "AS"), 0.0)
                    nb_val_db = next((v for k, v in temp_numeric.items() if k.strip().upper() == "NB"), 0.0)
                    sn_val_db = next((v for k, v in temp_numeric.items() if k.strip().upper() == "SN"), 0.0)
                    ti_val_db = next((v for k, v in temp_numeric.items() if k.strip().upper() == "TI"), 0.0)
                    w_val_db = next((v for k, v in temp_numeric.items() if k.strip().upper() == "W"), 0.0)
                    b_val_db = next((v for k, v in temp_numeric.items() if k.strip().upper() == "B"), 0.0)
                    co_val_db = next((v for k, v in temp_numeric.items() if k.strip().upper() == "CO"), 0.0)
                    pb_val_db = next((v for k, v in temp_numeric.items() if k.strip().upper() == "PB"), 0.0)
                    v_val_db = next((v for k, v in temp_numeric.items() if k.strip().upper() == "V"), 0.0)
                    zn_val_db = next((v for k, v in temp_numeric.items() if k.strip().upper() == "ZN"), 0.0)
                    mg_val_db = next((v for k, v in temp_numeric.items() if k.strip().upper() == "MG"), 0.0)
                    ce_val_db = next((v for k, v in temp_numeric.items() if k.strip().upper() == "CE"), 0.0)
                    la_val_db = next((v for k, v in temp_numeric.items() if k.strip().upper() == "LA"), 0.0)

                    with conn.session as s:
                        s.execute(
                            text("""
                                UPDATE materials SET 
                                    carbon_equivalent_cev = :cev,
                                    c_pct = :c, si_pct = :si, mn_pct = :mn, p_pct = :p, s_pct = :s,
                                    cr_pct = :cr, mo_pct = :mo, ni_pct = :ni, cu_pct = :cu, al_pct = :al,
                                    as_pct = :as, nb_pct = :nb, sn_pct = :sn, ti_pct = :ti, w_pct = :w,
                                    b_pct = :b, co_pct = :co, pb_pct = :pb, v_pct = :v, zn_pct = :zn,
                                    mg_pct = :mg, ce_pct = :ce, la_pct = :la,
                                    spectrometer_data_json = :spec_json
                                WHERE id = :id
                            """),
                            params={
                                "cev": float(calc_cev),
                                "c": float(c_val_db), "si": float(si_val_db), "mn": float(mn_val_db),
                                "p": float(p_val_db), "s": float(s_val_db), "cr": float(cr_val_db),
                                "mo": float(mo_val_db), "ni": float(ni_val_db), "cu": float(cu_val_db),
                                "al": float(al_val_db), "as": float(as_val_db), "nb": float(nb_val_db),
                                "sn": float(sn_val_db), "ti": float(ti_val_db), "w": float(w_val_db),
                                "b": float(b_val_db), "co": float(co_val_db), "pb": float(pb_val_db),
                                "v": float(v_val_db), "zn": float(zn_val_db), "mg": float(mg_val_db),
                                "ce": float(ce_val_db), "la": float(la_val_db),
                                "spec_json": spec_payload,
                                "id": int(mat_id)
                            }
                        )
                        s.commit()
                    st.toast("Spectrometer analysis saved to cloud via SQL!", icon="☁️")
                except Exception as db_err:
                    st.warning(f"Cloud sync error: {db_err}")
        
        if mat_id in st.session_state.chemical_reports:
            saved_spec = st.session_state.chemical_reports[mat_id]
            st.success("Spectrometer Data Loaded Successfully!")
            st.dataframe(saved_spec["df"], use_container_width=True)
            
            numeric_comp = {
                k.replace(" (%)", ""): v for k, v in saved_spec["comp"].items() 
                if isinstance(v, (int, float)) and "Fe" not in k
            }
            
            if numeric_comp:
                st.markdown("#### 📊 Alloy Elements Distribution (Excluding Base Iron)")
                fig_chem, ax_chem = plt.subplots(figsize=(6, 3))
                ax_chem.bar(list(numeric_comp.keys()), list(numeric_comp.values()), color="#28A745")
                ax_chem.set_ylabel("Concentration [%]")
                ax_chem.grid(axis="y", linestyle=":", alpha=0.7)
                plt.xticks(rotation=45, ha="right")
                fig_chem.tight_layout()
                st.pyplot(fig_chem)
            
            try:
                c_val = next((v for k, v in numeric_comp.items() if k.strip().upper() == "C"), 0.0)
                mn_val = next((v for k, v in numeric_comp.items() if k.strip().upper() == "MN"), 0.0)
                cr_val = next((v for k, v in numeric_comp.items() if k.strip().upper() == "CR"), 0.0)
                mo_val = next((v for k, v in numeric_comp.items() if k.strip().upper() == "MO"), 0.0)
                v_val = next((v for k, v in numeric_comp.items() if k.strip().upper() == "V"), 0.0)
                ni_val = next((v for k, v in numeric_comp.items() if k.strip().upper() == "NI"), 0.0)
                cu_val = next((v for k, v in numeric_comp.items() if k.strip().upper() == "CU"), 0.0)
                p_val = next((v for k, v in numeric_comp.items() if k.strip().upper() == "P"), 0.0)
                s_val = next((v for k, v in numeric_comp.items() if k.strip().upper() == "S"), 0.0)
                
                cev = float(c_val) + float(mn_val)/6.0 + (float(cr_val)+float(mo_val)+float(v_val))/5.0 + (float(ni_val)+float(cu_val))/15.0
                total_impurities = float(p_val) + float(s_val)
                is_clean = (float(p_val) <= 0.030) and (float(s_val) <= 0.100)
                impurity_status = "✅ Clean (Pass)" if is_clean else "❌ High Impurities (Fail)"
                
                col_m1, col_m2, col_m3 = st.columns(3)
                with col_m1:
                    st.metric(label="Carbon Equivalent (CEV IIW)", value=f"{cev:.3f}%")
                with col_m2:
                    st.metric(label="Total Impurities (P + S)", value=f"{total_impurities:.3f}%")
                with col_m3:
                    st.metric(label="Metallurgical Cleanliness", value=impurity_status)
            except Exception:
                st.metric(label="Calculated Carbon Equivalent (CEV IIW)", value="N/A")

        with action_col:
            st.subheader("Dog Bone Tensile Test CSV Processing")
            st.caption("Upload multiple CSV files corresponding to dog bone specimens for this material.")
            
            uploaded_dogbones = st.file_uploader(
                "Upload Dog Bone CSV Files", 
                type=["csv"], 
                accept_multiple_files=True,
                key=f"uploader_{mat_id}"
            )

            if st.button("Process & Save Dog Bone Data to Cloud", key=f"process_btn_{mat_id}"):
                if not uploaded_dogbones:
                    st.warning("Please upload at least one dog bone CSV file before processing.")
                else:
                    runs_data = []
                    os.makedirs("temp_uploads", exist_ok=True)
                    for uploaded_file in uploaded_dogbones:
                        temp_path = os.path.join("temp_uploads", uploaded_file.name)
                        with open(temp_path, "wb") as f:
                            f.write(uploaded_file.getbuffer())
                        runs_data.append(convert_curve(temp_path))
                    
                    results_computed = average_curves(runs_data)
                    curve_payload_dict = {
                        "strain": results_computed["eng_strain_clean"].tolist() if hasattr(results_computed["eng_strain_clean"], "tolist") else list(results_computed["eng_strain_clean"]),
                        "stress_MPa": (results_computed["eng_stress_clean"] * 1000.0).tolist() if hasattr(results_computed["eng_stress_clean"], "tolist") else list(results_computed["eng_stress_clean"] * 1000.0),
                        "sigy_MPa": float(results_computed["sigy_GPa"] * 1000.0),
                        "uts_MPa": float(results_computed["uts_GPa"] * 1000.0),
                        "E_GPa": float(results_computed["E_GPa"]),
                        "elongation_pct": float(results_computed["elongation_pct"]),
                        "avg_strain": results_computed["avg_strain"].tolist() if hasattr(results_computed["avg_strain"], "tolist") else list(results_computed["avg_strain"]),
                        "avg_stress": results_computed["avg_stress"].tolist() if hasattr(results_computed["avg_stress"], "tolist") else list(results_computed["avg_stress"]),
                        "eng_strain_clean": results_computed["eng_strain_clean"].tolist() if hasattr(results_computed["eng_strain_clean"], "tolist") else list(results_computed["eng_strain_clean"]),
                        "eng_stress_clean": results_computed["eng_stress_clean"].tolist() if hasattr(results_computed["eng_stress_clean"], "tolist") else list(results_computed["eng_stress_clean"]),
                        "deck": results_computed["deck"]
                    }
                    
                    st.session_state.experimental_curves[mat_id] = {
                        "strain": np.array(curve_payload_dict["strain"]),
                        "stress_MPa": np.array(curve_payload_dict["stress_MPa"]),
                        "sigy_MPa": curve_payload_dict["sigy_MPa"],
                        "uts_MPa": curve_payload_dict["uts_MPa"],
                        "E_GPa": curve_payload_dict["E_GPa"],
                        "elongation_pct": curve_payload_dict["elongation_pct"],
                        "avg_strain": np.array(curve_payload_dict["avg_strain"]),
                        "avg_stress": np.array(curve_payload_dict["avg_stress"]),
                        "eng_strain_clean": np.array(curve_payload_dict["eng_strain_clean"]),
                        "eng_stress_clean": np.array(curve_payload_dict["eng_stress_clean"]),
                        "deck": curve_payload_dict["deck"]
                    }
                    
                    try:
                        mech_json_payload = json.dumps(curve_payload_dict)
                        with conn.session as s:
                            s.execute(
                                text("""
                                    UPDATE materials SET 
                                        experimental_curves_json = :mech_json,
                                        calculated_sigy_mpa = :sigy,
                                        calculated_uts_mpa = :uts,
                                        calculated_e_gpa = :egpa,
                                        calculated_elongation_pct = :elong
                                    WHERE id = :id
                                """),
                                params={
                                    "mech_json": mech_json_payload,
                                    "sigy": float(results_computed["sigy_GPa"] * 1000.0),
                                    "uts": float(results_computed["uts_GPa"] * 1000.0),
                                    "egpa": float(results_computed["E_GPa"]),
                                    "elong": float(results_computed["elongation_pct"]),
                                    "id": int(mat_id)
                                }
                            )
                            s.commit()
                            st.cache_data.clear() 
                            st.toast("Dog bone analysis saved to cloud via SQL!", icon="☁️")
                            st.success(f"Successfully processed and saved {len(runs_data)} specimen run(s)!")
                            st.rerun() 
                    except Exception as db_err:
                        st.warning(f"Cloud sync error for mechanical data: {db_err}")

            if mat_id not in st.session_state.experimental_curves:
                saved_json = mat_info.get("experimental_curves_json") if "experimental_curves_json" in mat_info else None
                if saved_json:
                    loaded_dict = json.loads(saved_json) if isinstance(saved_json, str) else saved_json
                    st.session_state.experimental_curves[mat_id] = {
                        "strain": np.array(loaded_dict["strain"]),
                        "stress_MPa": np.array(loaded_dict["stress_MPa"]),
                        "sigy_MPa": loaded_dict["sigy_MPa"],
                        "uts_MPa": loaded_dict["uts_MPa"],
                        "E_GPa": loaded_dict["E_GPa"],
                        "elongation_pct": loaded_dict["elongation_pct"],
                        "avg_strain": np.array(loaded_dict["avg_strain"]),
                        "avg_stress": np.array(loaded_dict["avg_stress"]),
                        "eng_strain_clean": np.array(loaded_dict["eng_strain_clean"]),
                        "eng_stress_clean": np.array(loaded_dict["eng_stress_clean"]),
                        "deck": loaded_dict["deck"]
                    }

            results = st.session_state.experimental_curves.get(mat_id, None)

            if results:
                st.metric(label="Calculated Young's Modulus (E)", value=f"{results['E_GPa']:.2f} GPa")
                st.metric(label="Calculated Lab Yield Avg (sigy)", value=f"{results['sigy_MPa']:.1f} MPa")
                st.metric(label="Calculated Lab Ultimate Stress (UTS)", value=f"{results['uts_MPa']:.1f} MPa")
                st.metric(label="Calculated Elongation (A%)", value=f"{results.get('elongation_pct', 0.0):.2f} %")
            else:
                st.info("Upload tensile test CSV logs above and click process to calculate true strain/stress properties.")

            if results:
                st.write("---")
                plot_col, deck_col = st.columns([1, 1])
                
                with plot_col:
                    st.subheader("📈 Averaged Stress-Strain Trajectory")
                    fig, ax = plt.subplots(figsize=(6, 4.5))
                    
                    ax.plot(results["avg_strain"], results["avg_stress"] * 1000.0, label="Raw Engineering Average", color="navy", linestyle="--")
                    ax.plot(results["eng_strain_clean"], results["eng_stress_clean"] * 1000.0, label="Monotonic Clean Filter", color="orange", lw=2)
                    
                    ax.set_xlabel("Strain [-]")
                    ax.set_ylabel("Stress [MPa]")
                    ax.grid(True, linestyle=":")
                    ax.legend()
                    st.pyplot(fig)

                with deck_col:
                    st.subheader("💾 LS-DYNA Keyword Deck Export")
                    st.caption("MAT_024 card automatically generated from experimental curves.")
                    st.text_area("Keyword Output Preview", results["deck"], height=280)
                    
                    st.download_button(
                        label="📥 Download MAT_024 Keyword Deck (*.k)",
                        data=results["deck"],
                        file_name=f"MAT_024_{mat_info['grade']}_{int(mat_info['thickness']*100)}mm.k",
                        mime="text/plain"
                    )
 
# =========================================================================
# ### SECTION 6: PRODUCTION QUALITY CONTROL HUB PAGE ###
# =========================================================================
elif st.session_state.current_page == "PROD_HUB":
    if st.button("← Return to Central Portal"):
        st.session_state.current_page = "HOME"
        st.session_state.selected_material = None
        st.rerun()
        
    family_name = st.session_state.active_family.title()
    st.title(f"{family_name} — Production Quality Control Hub")
    st.write("---")
    
    # 1. FETCH DATA FIRST
    prod_df = fetch_cloud_materials(family=st.session_state.active_family)
    
    # --- BUILD GROUPED STORAGE FOR WAREHOUSE CARDS ---
    if not prod_df.empty:
        temp_storage_df = prod_df.copy()
        temp_storage_df['calc_weight_kg'] = temp_storage_df['rd_remaining_weight_kg'].fillna(temp_storage_df['coil_weight_kg'])
        temp_storage_df['calc_weight_kg'] = temp_storage_df['calc_weight_kg'].apply(lambda x: 0.0 if x <= 0.001 else x)
        
        grouped_storage = temp_storage_df.groupby(['grade', 'thickness']).agg(
            coil_count=('lotto_number', 'nunique'),
            total_weight=('calc_weight_kg', 'sum'),
            lots=('lotto_number', lambda x: ", ".join(x.dropna().astype(str).unique()))
        ).reset_index()
    else:
        grouped_storage = pd.DataFrame(columns=['grade', 'thickness', 'coil_count', 'total_weight', 'lots'])

    # --- Warehouse Coil Situation Section ---
    st.markdown("### 🏭 Warehouse Coil Situation")
    
    if not grouped_storage.empty:
        cards_html = ""
        for idx, row in grouped_storage.iterrows():
            grade = row['grade']
            thick = row['thickness']
            count = row['coil_count']
            
            tot_w_kg = row['total_weight']
            tot_w_tons = tot_w_kg / 1000.0
            lots_list = row['lots']
            
            if len(lots_list) > 35:
                lots_display = lots_list[:32] + "..."
            else:
                lots_display = lots_list
            
            # RULE 1: Highlight card in red ONLY if Father coil count is strictly under 2
            is_low = (count < 2)
            border_color = "#ff4b4b" if is_low else "#2e7d32"
            bg_color = "#fff5f5" if is_low else "#f1f8e9"
            
            coil_svg = """<svg width="75" height="62" viewBox="0 0 120 100" style="margin: 0 4px 4px 0; filter: drop-shadow(1px 2px 2px rgba(0,0,0,0.15));">
    <ellipse cx="40" cy="50" rx="30" ry="42" fill="#d0d0d0" stroke="#444" stroke-width="4"/>
    <path d="M 40 8 L 85 8 C 98 8, 98 92, 85 92 L 40 92" fill="#e8e8e8" stroke="#444" stroke-width="4"/>
    <path d="M 25 22 L 70 22" stroke="#222" stroke-width="5" stroke-linecap="round"/>
    <path d="M 25 78 L 70 78" stroke="#222" stroke-width="5" stroke-linecap="round"/>
    <ellipse cx="85" cy="50" rx="14" ry="42" fill="#fcfcfc" stroke="#444" stroke-width="4"/>
    <ellipse cx="85" cy="50" rx="10" ry="30" fill="#e0e0e0" stroke="#666" stroke-width="2"/>
    <ellipse cx="85" cy="50" rx="5" ry="15" fill="#333"/>
</svg>"""
            coil_icons_html = "".join([coil_svg for _ in range(int(count))])
            
            cards_html += f"""<div style="border: 2px solid {border_color}; background-color: {bg_color}; padding: 12px; border-radius: 8px; text-align: left; box-shadow: 0 2px 4px rgba(0,0,0,0.04); display: inline-block; width: 270px; vertical-align: top; margin: 6px;">
<div style="font-weight: bold; color: #111; font-size: 15px; margin-bottom: 8px;">
{grade} | {thick} mm
</div>
<div style="margin-bottom: 8px; display: flex; justify-content: flex-start; align-items: center; flex-wrap: wrap;">
{coil_icons_html}
</div>
<div style="font-size: 13px; color: #333; margin-bottom: 4px;">
<b>Coils:</b> <span style="color: {'#ff4b4b' if count < 2 else '#1f77b4'}; font-weight: bold;">{count}</span> | <b>Weight:</b> <span style="color: {border_color}; font-weight: bold;">{tot_w_tons:.3f} t</span>
</div>
<div style="font-size: 11px; color: #666; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="{lots_list}">
<b>Lots:</b> {lots_display}
</div>
</div>"""

        st.markdown(f"""<div style="display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 16px;">
{cards_html}
</div>""", unsafe_allow_html=True)
    else:
        st.info("No active coils currently in storage.")
    
    st.write("---")

    # --- Production Batch Queue Header ---
    st.markdown(f"### 📦 Production Batch Queue ({family_name})")
    st.caption("💡 *Rows highlighted in light red indicate any Lotto (Father or Son) at or below the 20 Ton low-stock threshold.*")
    search_query = st.text_input("🔍 Search by Lotto Number (Father or Son)", value="")
    
    if not prod_df.empty:
        prod_df['current_weight_kg'] = prod_df['rd_remaining_weight_kg'].fillna(prod_df['coil_weight_kg'])
        prod_df['current_length_mm'] = prod_df['rd_remaining_length_mm'].fillna(prod_df['coil_length_mm'])
        prod_df['current_weight_kg'] = prod_df['current_weight_kg'].apply(lambda x: 0.0 if x <= 0.001 else x)
        prod_df['current_length_mm'] = prod_df['current_length_mm'].apply(lambda x: 0.0 if x <= 0.01 else x)

        prod_df['current_weight_tons'] = prod_df['current_weight_kg'] / 1000.0

        display_df = prod_df[[
            "id", "grade", "thickness", "yield_mpa", "uts_mpa", "elongation_pct", 
            "current_weight_tons", "current_length_mm", "lotto_number", "lotto_figlio", "provider", 
            "rd_remaining_weight_kg", "is_promoted"
        ]].copy()
        
        def determine_status(row):
            if row["rd_remaining_weight_kg"] is not None and float(row["rd_remaining_weight_kg"]) <= 0.001:
                return "🔴 Not Available"
            elif row["is_promoted"] == 1:
                return "🚀 R&D Promoted"
            else:
                return "🟢 In Production"

        display_df["Status"] = display_df.apply(determine_status, axis=1)
        display_df = display_df.drop(columns=["rd_remaining_weight_kg", "is_promoted"])
        
        display_df = display_df.rename(columns={
            "current_weight_tons": "Remaining Weight [t]",
            "current_length_mm": "Remaining Length [mm]",
            "lotto_number": "Lotto Father",
            "lotto_figlio": "Lotto Son"
        })
        
        if search_query.strip():
            q = search_query.strip().lower()
            mask = display_df["Lotto Father"].astype(str).str.lower().str.contains(q) | display_df["Lotto Son"].astype(str).str.lower().str.contains(q)
            display_df = display_df[mask]
            
        def highlight_low_stock(row):
            w_tons = row.get('Remaining Weight [t]', 0)
            if 0.0001 < w_tons <= 20.0:
                return ['background-color: #ffebee'] * len(row)
            return [''] * len(row)

        styled_df = display_df.set_index('id').style.apply(highlight_low_stock, axis=1)
        st.dataframe(styled_df, use_container_width=True)
    else:
        st.info("No production batches in database queue.")

    st.write("---")
    
    # 3. ACTIONS, EDITS, AND SPLIT COIL CONTROLS
    p_col1, p_col2 = st.columns([1.2, 0.8])
    
    with p_col2:
        st.subheader("Actions & Edits")
        if not prod_df.empty:
            active_prod_df = prod_df[
                prod_df['rd_remaining_weight_kg'].isna() | 
                (prod_df['rd_remaining_weight_kg'] > 0.001)
            ]
            
            if not active_prod_df.empty:
                def format_batch_option(x):
                    row_data = active_prod_df[active_prod_df['id'] == x].iloc[0]
                    grade = row_data['grade']
                    father = str(row_data['lotto_number']) if pd.notna(row_data['lotto_number']) else ""
                    son = str(row_data['lotto_figlio']) if pd.notna(row_data['lotto_figlio']) else ""
                    if son and father and father != "None":
                        lotto_str = f"{father} → {son}"
                    elif son and son != "None":
                        lotto_str = son
                    else:
                        lotto_str = father if father != "None" else "No Lotto"
                    return f"ID {x}: {grade} ({lotto_str})"

                selected_prod_id = st.selectbox(
                    "Select Production Batch", 
                    active_prod_df["id"].tolist(),
                    format_func=format_batch_option
                )
                
                selected_row = active_prod_df[active_prod_df['id'] == selected_prod_id].iloc[0]
                is_already_promoted = (selected_row["is_promoted"] == 1)

                b1, b2 = st.columns(2)
                with b1:
                    if is_already_promoted:
                        st.info("Already in R&D")
                    else:
                        if st.button("Move to R&D", use_container_width=True):
                            promote_cloud_material(selected_prod_id)
                            st.success(f"Batch ID {selected_prod_id} promoted to R&D!")
                            st.cache_data.clear()
                            st.rerun()
                            
                with b2:
                    if "confirm_delete_id" not in st.session_state:
                        st.session_state.confirm_delete_id = None

                    if st.session_state.confirm_delete_id == selected_prod_id:
                        st.warning("Are you sure?")
                        col_yes, col_no = st.columns(2)
                        with col_yes:
                            if st.button("Yes, Delete", key=f"yes_del_{selected_prod_id}", use_container_width=True):
                                delete_cloud_material(selected_prod_id)
                                st.session_state.confirm_delete_id = None
                                st.success(f"Batch ID {selected_prod_id} deleted!")
                                st.cache_data.clear()
                                st.rerun()
                        with col_no:
                            if st.button("Cancel", key=f"no_del_{selected_prod_id}", use_container_width=True):
                                st.session_state.confirm_delete_id = None
                                st.rerun()
                    else:
                        if st.button("🗑️ Delete Batch", use_container_width=True):
                            st.session_state.confirm_delete_id = selected_prod_id
                            st.rerun()

                with st.expander("✏️ Edit Selected Batch Values"):
                    with st.form(key=f"edit_form_{selected_prod_id}"):
                        new_grade = st.text_input("Grade", value=str(selected_row["grade"]))
                        new_thickness = st.number_input("Thickness [mm]", value=float(selected_row["thickness"]), step=0.1)
                        new_yield = st.number_input("Yield Stress [MPa]", value=float(selected_row["yield_mpa"]), step=5.0)
                        new_uts = st.number_input("Failure Stress [MPa]", value=float(selected_row["uts_mpa"]), step=5.0)
                        new_elong = st.number_input("Elongation [%]", value=float(selected_row["elongation_pct"]), step=0.5)
                        new_weight = st.number_input("Coil Weight [kg]", value=float(selected_row.get("coil_weight_kg", 0.0)), step=50.0)
                        new_length = st.number_input("Coil Length [mm]", value=float(selected_row.get("coil_length_mm", 0.0)), step=100.0)
                        
                        val_padre = selected_row["lotto_number"] if pd.notna(selected_row["lotto_number"]) else ""
                        val_figlio = selected_row["lotto_figlio"] if pd.notna(selected_row["lotto_figlio"]) else ""
                        
                        new_lotto_padre = st.text_input("Lotto Father", value=str(val_padre))
                        new_lotto_figlio = st.text_input("Lotto Son", value=str(val_figlio))
                        new_provider = st.text_input("Provider", value=str(selected_row["provider"]))
                        
                        if st.form_submit_button("💾 Save Changes", use_container_width=True):
                            update_cloud_material(
                                selected_prod_id, 
                                grade=new_grade, thickness=new_thickness, 
                                yield_mpa=new_yield, uts_mpa=new_uts, 
                                elongation_pct=new_elong, lotto_number=new_lotto_padre, 
                                lotto_figlio=new_lotto_figlio, provider=new_provider,
                                coil_weight_kg=new_weight, coil_length_mm=new_length
                            )
                            st.success("Batch updated successfully!")
                            st.cache_data.clear()
                            st.rerun()

                # --- SPLIT COIL CONTROLS ---
                with st.expander("✂️ Split Coil (Father -> Sons)", expanded=False):
                    rem_w_val = selected_row.get("rd_remaining_weight_kg")
                    current_w = float(rem_w_val) if pd.notna(rem_w_val) else float(selected_row.get("coil_weight_kg", 0.0))

                    rem_l_val = selected_row.get("rd_remaining_length_mm")
                    current_l = float(rem_l_val) if pd.notna(rem_l_val) else float(selected_row.get("coil_length_mm", 0.0))
                    
                    base_lotto = selected_row['lotto_figlio'] if pd.notna(selected_row['lotto_figlio']) else selected_row['lotto_number']
                    
                    st.write(f"Available to split: **{current_w:.2f} kg** / **{current_l:.2f} mm**")
                    
                    num_children = st.number_input("Number of Sons", min_value=2, max_value=10, value=2, step=1)
                    
                    with st.form(key=f"split_form_{selected_prod_id}"):
                        children_inputs = []
                        letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                        weight_per_mm = current_w / current_l if current_l > 0 else 0.0
                        
                        for i in range(int(num_children)):
                            st.markdown(f"**Son {i+1} (Son {letters[i]})**")
                            cc1, cc2, cc3 = st.columns(3)
                            with cc1:
                                c_lotto = st.text_input(f"Lot Name {i+1}", value=f"{base_lotto}-{letters[i]}", key=f"split_lotto_{selected_prod_id}_{i}")
                            with cc2:
                                c_length = st.number_input(f"Length {i+1} [mm]", min_value=0.0, max_value=current_l, value=0.0, key=f"split_l_{selected_prod_id}_{i}")
                            with cc3:
                                c_weight = c_length * weight_per_mm
                                st.write(f"Weight {i+1} [kg]")
                                st.metric(label="", value=f"{c_weight:.2f} kg")
                            
                            children_inputs.append({"lotto": c_lotto, "weight": c_weight, "length": c_length})
                            st.write("---")
                            
                        if st.form_submit_button("Confirm Split & Close Parent", use_container_width=True):
                            total_l = sum(c["length"] for c in children_inputs)
                            if total_l > current_l:
                                st.error("Sum of child lengths exceeds parent remaining length!")
                            else:
                                split_cloud_material(selected_prod_id, children_inputs)
                                for idx in range(int(num_children)):
                                    key_l = f"split_l_{selected_prod_id}_{idx}"
                                    key_lot = f"split_lotto_{selected_prod_id}_{idx}"
                                    if key_l in st.session_state: del st.session_state[key_l]
                                    if key_lot in st.session_state: del st.session_state[key_lot]
                                st.success(f"Coil successfully split into {num_children} sons!")
                                st.cache_data.clear()
                                st.rerun()
            else:
                st.info("No active production batches available for actions.")

    st.write("---")
    
    # 4. MANUAL FORM ENTRY & FILE UPLOAD
    with st.expander("✍️ Manual Form Entry & File Upload (New Batch)", expanded=False):
        entry_tab1, entry_tab2 = st.tabs(["Manual Form Entry", "📁 File Upload (.txt / .csv / .xlsx)"])
        
        with entry_tab1:
            with st.form("prod_form_manual", clear_on_submit=True):
                ca, cb = st.columns(2)
                with ca:
                    grade = st.text_input("1. Material Grade / Name", value="")
                    thickness = st.number_input("2. Thickness [mm]", value=None, step=0.1)
                    sig_yield = st.number_input("3. Yield Stress σ_yield [MPa]", value=None, step=5.0)
                    sig_fail = st.number_input("4. Ultimate Stress σ_uts [MPa]", value=None, step=5.0)
                    elongation = st.number_input("5. Elongation [%]", value=None, step=0.5)
                with cb:
                    lotto_padre = st.text_input("6. Lotto Father", value="")
                    lotto_figlio = st.text_input("7. Lotto Son", value="")
                    provider = st.text_input("8. Material Supplier", value="")
                    coil_weight = st.number_input("9. Coil Weight [TON]", value=None, step=50.0)
                    coil_length = st.number_input("10. Coil Length [mm]", value=None, step=1000.0)
                
                uploaded_cert = st.file_uploader("Upload Test Certificate (.pdf, .png, .jpg)", type=["pdf", "png", "jpg", "jpeg"])
                
                if st.form_submit_button("💾 Save Batch", use_container_width=True):
                    cert_url = None
                    active_lotto_label = lotto_padre if lotto_padre else (lotto_figlio if lotto_figlio else "batch")
                    if uploaded_cert is not None:
                        cert_url = upload_certificate_to_cloud(uploaded_cert, active_lotto_label)

                    insert_cloud_material(
                        grade, thickness, sig_yield, sig_fail, elongation, 
                        lotto_padre=lotto_padre, lotto_figlio=lotto_figlio, provider=provider, 
                        family=st.session_state.active_family,
                        cert_path=cert_url,
                        coil_weight=coil_weight,
                        coil_length_mm=coil_length
                    )
                    st.success("Batch registered into Production database!")
                    st.cache_data.clear()
                    st.rerun()

        with entry_tab2:
            uploaded_file = st.file_uploader("Upload Batch Import File", type=["txt", "csv", "xlsx"])
            if uploaded_file is not None:
                try:
                    filename = uploaded_file.name.lower()
                    if filename.endswith(".txt") or filename.endswith(".csv"):
                        df_upload = pd.read_csv(
                            uploaded_file, 
                            header=None,
                            names=["grade", "thickness", "yield_ns", "uts_ns", "elong_ns", "lotto_number", "lotto_figlio", "provider", "coil_weight_kg", "coil_length_mm"]
                        )
                    elif filename.endswith(".xlsx"):
                        df_upload = pd.read_excel(uploaded_file)
                        if "lotto_figlio" not in df_upload.columns:
                            df_upload["lotto_figlio"] = None

                    for col in df_upload.select_dtypes(include=["object"]).columns:
                        df_upload[col] = df_upload[col].astype(str).str.strip()
                    st.dataframe(df_upload, use_container_width=True)

                    if st.button("Import Batches to Database", use_container_width=True):
                        for _, r in df_upload.iterrows():
                            insert_cloud_material(
                                r["grade"], r["thickness"], 
                                r["yield_mpa"] if "yield_mpa" in r else r.get("yield_ns", 0.0), 
                                r["uts_mpa"] if "uts_mpa" in r else r.get("uts_ns", 0.0), 
                                r["elongation_pct"] if "elongation_pct" in r else r.get("elong_ns", 0.0), 
                                r.get("lotto_number"), r.get("lotto_figlio"), 
                                r["provider"],
                                family=st.session_state.active_family,
                                cert_path=None,
                                coil_weight=r.get("coil_weight_kg", 0.0),
                                coil_length_mm=r.get("coil_length_mm", 0.0)
                            )
                        st.success("Successfully imported production batches!")
                        st.cache_data.clear()
                        st.rerun()
                except Exception as e:
                    st.error(f"Error reading file structure: {e}")